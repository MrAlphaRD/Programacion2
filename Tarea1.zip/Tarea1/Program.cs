﻿internal class Program
{
    public static void Main(string[] args)
    {
        {
        Msi msi = new Msi("MSI", "GL62M", "Nueva");
        Console.WriteLine(msi.getMarca());
        Console.WriteLine(msi.getModelo());
        Console.WriteLine(msi.getEstado());
        msi.Prender();
        msi.Apagar();
        Console.ReadKey();
    }
    }

    
    
}