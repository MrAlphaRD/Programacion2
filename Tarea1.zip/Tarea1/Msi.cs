class Msi : Computadora
{
    public Msi(string marca, string modelo, string estado) : base(marca, modelo, estado)
    {
        Marca = marca;
        Modelo = modelo;
        Estado = estado;
        this.marca = marca;
        this.modelo = modelo;
        this.estado = estado;
    }
    private string marca;
    private string modelo;
    private string estado;

    

    // Setters y Getters
    public void setMarca(string marca)
    {
        this.marca = marca;
    }

    public string getMarca()
    {
        return marca;
    }

    public void setModelo(string modelo)
    {
        this.modelo = modelo;
    }

    public string getModelo()
    {
        return modelo;
    }

    public void setEstado(string estado)
    {
        this.estado = estado;
    }

    public string getEstado()
    {
        return estado;
    }
}