class Computadora
{
    private String marca;
    private String modelo;
    private String estado;

    public Computadora(string marca, string modelo, string estado)
    {
        Marca = marca;
        Modelo = modelo;
        Estado = estado;
        this.marca = marca;
        this.modelo = modelo;
        this.estado = estado;
    }

    // Metodos
    public void Prender()
    {
        Console.WriteLine("Enciende la pc");
    }
    public void Apagar()
    {
        Console.WriteLine("Apaga la pc");
    }

    // Propiedades

    public string Marca { get; set; }
    public string Modelo { get; set; }
    public string Estado { get; set; }
}